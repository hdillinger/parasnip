########################################################################
#
# readVTKXML.py
# Reader for VTK XML files
#
# Implemented in Python 3.5
#
########################################################################
#
# Published under the MIT License. See the file LICENSE for details.
#
# Copyright 2018 by Hannes Dillinger
#
########################################################################

import vtk
from vtk.util import numpy_support
import numpy as np
import scipy.io as sio
from scipy.interpolate import griddata

########################################################################
# Read vtkXMLUnstructuredGrid file
########################################################################

filename = './data/polydata_0.vtu'

reader = vtk.vtkXMLUnstructuredGridReader()
reader.SetFileName(filename)
reader.Update()

mapper = vtk.vtkDataSetMapper()
mapper.SetInputConnection(reader.GetOutputPort())

actor = vtk.vtkActor()
actor.SetMapper(mapper)

########################################################################
# Read vtkXMLPolyData file
########################################################################

filename2 = './data/polydata_0.vtp'

reader2 = vtk.vtkXMLPolyDataReader()
reader2.SetFileName(filename2)
reader2.Update()

mapper2 = vtk.vtkDataSetMapper()
mapper2.SetInputConnection(reader2.GetOutputPort())

actor2 = vtk.vtkActor()
actor2.SetMapper(mapper2)

########################################################################
# Display data in VTK window
########################################################################

renderer = vtk.vtkRenderer()
renderWindow = vtk.vtkRenderWindow()
renderWindow.AddRenderer(renderer)

renderWindowInteractor = vtk.vtkRenderWindowInteractor()
renderWindowInteractor.SetRenderWindow(renderWindow)

# renderer.AddActor(actor)
renderer.AddActor(actor2)

########################################################################
# Render VTK window
########################################################################

renderWindow.Render()
renderWindowInteractor.Start()

########################################################################
# Save to MATLAB File
########################################################################

data = reader2.GetOutput()
points = data.GetPoints().GetData()

mapper = vtk.vtkCellDataToPointData()
mapper.AddInputData(data)
mapper.Update()

press = mapper.GetOutput().GetPointData().GetArray('p')
vels = mapper.GetOutput().GetPointData().GetArray('U')

press = numpy_support.vtk_to_numpy(press)
vels = numpy_support.vtk_to_numpy(vels)
points = numpy_support.vtk_to_numpy(points)

x = points[:, 0]
y = points[:, 1]
z = points[:, 2]

# grid
npts = 100
xmin, xmax = min(x)-1, max(x)+1
ymin, ymax = min(y)-1, max(y)+1
zmin, zmax = min(z)-1, max(z)+1

# define grid
xi = np.linspace(xmin, xmax, npts)
yi = np.linspace(ymin, ymax, npts)
zi = np.linspace(zmin, zmax, npts)

# grid the data
# 3D data method linear
# pi = griddata((x, y, z), press, (xi[None, :], yi[:, None], zi[:, None]), method='linear')
# 1D and 2D: cubic method possible
pi = griddata((x, y), press, (xi[None, :], yi[:, None]), method='cubic')

# save new data
sio.savemat('vtk.mat', {'p': pi, 'x': xi, 'y': yi, 'z': zi})
